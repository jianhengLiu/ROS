#!/usr/bin/env python
#coding=utf-8
from pyc import Show_mark

if __name__ == '__main__':
  Show_mark.Show_mark()

